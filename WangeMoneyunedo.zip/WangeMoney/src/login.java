/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Unedo
 */
import java.util.Scanner;
public class login {
    Scanner input = new Scanner(System.in);
    String username;
    String password;
    String e_mail;
    
    public void setUsername(String username){
        this.username = username;
    }
    public void setPassword(String password){
         this.password = password;
    }
    public void setEmail(String e_mail){
        this.e_mail = e_mail;
    }
    public void login(String i){
        if(!i.equals(username)){
            System.out.println("Username anda salah, mohon diulangi");
            String ulang = input.nextLine();
            login(ulang);
        }
        else if(!i.equals(password)){
            System.out.println("Password Anda salah, mohon diulangi ");
            String ulang = input.nextLine();
            login(ulang);
        }
    }
}
