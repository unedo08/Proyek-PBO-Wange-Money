/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Unedo
 */
public class proses_transaksi {
    
    int topup, saldo;
    virtualAccount virtualAccountid;
    
    public void topUp(int topup){
        this.topup = topup;
    }
    public void infoSaldo(int saldo, int topup){
        saldo = 0;
        int infosaldo = 0;
        infosaldo = saldo + topup;
    }
    public void pembayaran(virtualAccount virtualAccount,int saldo){
        
    }
    
}
