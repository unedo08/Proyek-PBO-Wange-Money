/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Unedo
 */
import java.util.Scanner;
public class main {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        System.out.println("Atur username dan password terlebih dahulu");
        login data = new login();
        String username = input.nextLine();
        data.setUsername(username);
        String password = input.nextLine();
        data.setPassword(password);
        String e_mail = input.nextLine();
        System.out.println("====================\n");
        System.out.println("SELAMAT DATANG DI Wange Money");
        System.out.println("\n========================");
        
        System.out.println("LOGIN");
        System.out.println("------------------------");
        System.out.println("Masukkan username anda : ");
        
        System.out.println("Masukkan passwor anda : ");
        
    }
}